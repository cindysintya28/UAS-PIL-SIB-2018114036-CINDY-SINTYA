@extends('layout.app')

@section('title', 'absens')
@section('content')
<a href="/absens/create" type="button" class="btn btn-secondary mb-2 btn-sm">Tambah Absen</a>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Waktu Absen</th>
      <th scope="col">Mahasiswa ID</th>
      <th scope="col">Matakuliah ID</th>
      <th scope="col">Keterangan</th>
    </tr>
  </thead>
  <tbody>
  @foreach ($absens as $absen)
    <tr>
    <td>{{$absen->waktu_absen}}</td>
    <td>{!!$absen->mahasiswa_id !!}</td>
    <td>{!!$absen->matakuliah_id !!}</td>
    <td>{!!$absen->keterangan !!}</td>
    </tr>
    @endforeach
  </tbody>
</table>
<div>
    {{ $absens -> links() }}
    </div>
@endsection