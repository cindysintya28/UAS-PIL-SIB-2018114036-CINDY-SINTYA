@extends('layouts.app')

@section('title', 'absen')

@section('content')
<div class="card">
    <div class="card-body">
                <h3>Waktu Absen : {{ $absen['waktu_absen'] }}</h3>
                <h3>Mahasiswa ID : {{ $absen['mahasiswa_id'] }}</h3>
                <h3>Matakuliah ID : {{ $absen['matakuliah_id'] }}</h3>
                <h3>Keterangan : {{ $absen['keterangan] }}</h3>
                
    </div>
</div>
@endsection