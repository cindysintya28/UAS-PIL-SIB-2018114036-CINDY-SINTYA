@extends('layout.app')

@section('title', 'Jadwal')

@section('content')
<div class="card">
    <div class="card-body">
                <h3>Jadwal : {{ $jadwal['jadwal'] }}</h3>
                <h3>Matakuliah ID : {{ $jadwal['matakuliah_id'] }}</h3>
                
    </div>
</div>
@endsection