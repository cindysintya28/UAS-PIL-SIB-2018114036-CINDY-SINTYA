@extends('layout.app')

@section('title', 'Jadwals')
@section('content')
<a href="/jadwals/create" type="button" class="btn btn-secondary mb-2 btn-sm">Tambah Jadwal</a>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Jadwal</th>
      <th scope="col">Matakuliah ID</th>
      
    </tr>
  </thead>
  <tbody>
  @foreach ($jadwals as $jadwal)
    <tr>
    <td>{{$jadwal->jadwal}}</td>
    <td>{{$jadwal->matakuliah_id}}</td>
    </tr>
    @endforeach
  </tbody>
</table>
<div>
    {{ $jadwals -> links() }}
    </div>
@endsection