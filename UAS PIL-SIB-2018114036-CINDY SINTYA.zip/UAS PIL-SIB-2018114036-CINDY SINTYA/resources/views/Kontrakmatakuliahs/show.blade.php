@extends('layouts.app')

@section('title', 'kontrakmatakuliah')

@section('content')
<div class="card">
    <div class="card-body">
                <h3>Mahasiswa ID: {{ $kontrakmatakuliah['mahasiswa_id'] }}</h3>
                <h3>Semester ID : {{ $kontrakmatakuliah['semester_id'] }}</h3>
        
    </div>
</div>
@endsection