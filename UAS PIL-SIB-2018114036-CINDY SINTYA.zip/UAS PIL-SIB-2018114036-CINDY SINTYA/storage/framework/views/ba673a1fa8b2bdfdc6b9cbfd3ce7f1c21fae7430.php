<?php $__env->startSection('title', 'semesters'); ?>
<?php $__env->startSection('content'); ?>
<a href="/semesters/create" type="button" class="btn btn-secondary mb-2 btn-sm">Tambah Semester</a>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">Semester</th>
      
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($semester->semester); ?></td>
    
    <td><a href="/semesters/<?php echo e($semester->id); ?>/edit"><button type="button" class="btn btn-outline-secondary">Edit</a></button></td>
    <form action="/semesters/<?php echo e($semester->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <td><button class="btn btn-outline-secondary">Delete</button></td>
    </form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<div>
    <?php echo e($semesters -> links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absensimahasiswa\resources\views/semesters/index.blade.php ENDPATH**/ ?>