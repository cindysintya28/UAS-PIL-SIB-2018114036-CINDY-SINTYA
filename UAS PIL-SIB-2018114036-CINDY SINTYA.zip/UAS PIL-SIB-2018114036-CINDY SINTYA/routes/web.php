<?php

use App\Http\Controllers\LayoutController;
use App\Http\Controllers\AbsenController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\KontrakmatakuliahController;
use App\Http\Controllers\MahasiswaController;
use App\Http\Controllers\MatakuliahController;
use App\Http\Controllers\SemesterController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('',[AbsenController::class, 'index']);
Route::get('',[JadwalController::class, 'index']);
Route::get('',[KontrakmatakuliahController::class, 'index']);
Route::get('',[MahasiswaController::class, 'index']);
Route::get('',[MatakuliahController::class, 'index']);
Route::get('',[SemesterController::class, 'index']);

Route::resources([
    'absens' => AbsenController::class,
    'jadwals' => JadwalController::class,
    'kontrakmatakuliahs' => KontrakmatakuliahController::class,
    'mahasiswas' => MahasiswaController::class,
    'matakuliahs' => MatakuliahController::class,
    'semesters' => SemesterController::class,
]);
