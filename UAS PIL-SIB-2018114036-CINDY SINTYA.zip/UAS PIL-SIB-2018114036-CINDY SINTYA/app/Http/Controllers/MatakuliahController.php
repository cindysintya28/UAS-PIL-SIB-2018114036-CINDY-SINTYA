<?php

namespace App\Http\Controllers;
use App\Models\Matakuliahs;
use Illuminate\Http\Request;

class MatakuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $matakuliahs = Matakuliahs::orderBy('id','desc')->paginate(3);
        return view('matakuliahs.index', compact('matakuliahs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('matakuliahs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
        'nama_matakuliah' => 'required',
        'sks' => 'required',
       
        ]);

        $matakuliahs = new matakuliahs;

        $matakuliahs->nama_matakuliah = $request->nama_matakuliah;
        $matakuliahs->sks = $request->sks;
        
       
        $matakuliahs->save();
        return redirect('/matakuliahs');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Matakuliah = Matakuliahs::where('id', $id)->first();
        return view('matakuliahs.show' ,['matakuliah' => $Matakuliah]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Matakuliah = Matakuliahs::where('id', $id)->first();
        return view('matakuliahs.edit' , ['matakuliah' => $Matakuliah]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
        'nama_matakuliah' => 'required',
        'sks' => 'required',
        
        ]);
            Matakuliahs::find($id)->update([
            'nama_matakuliah' => $request->nama_matakuliah,
            'sks' => $request->sks,
            
            ]);
            
            return redirect('/matakuliahs');
    }
    public function destroy($id)
    {
        //
    }
}